"""
Export LibreLingo courses in the JSON format used by the web app
"""

import librelingo_json_export.export

__version__ = "0.7.1"
