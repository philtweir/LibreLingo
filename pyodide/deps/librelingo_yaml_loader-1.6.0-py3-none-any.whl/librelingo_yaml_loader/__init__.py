"""
Load YAML-based LibreLingo courses in your Python project.
"""

from librelingo_yaml_loader.yaml_loader import load_course

__version__ = "1.6.0"
