"""
librelingo-utils contains utility functions that are meant to make it easier
to create Python software that works with LibreLingo courses.
"""


from librelingo_utils.utils import *

__version__ = "2.5.0"
